# Credits
### [CCBlueX Foundation](https://github.com/CCBlueX) 
- Creating [LiquidBounce](https://github.com/CCBlueX/LiquidBounce/tree/legacy)
### [WYSI-Foundation](https://github.com/WYSI-Foundation) 
- Creating [LiquidBounce+](https://github.com/WYSI-Foundation/LiquidBouncePlus)
### [randomguy3725](https://github.com/randomguy3725) 
- Creating [LiquidBounce+ Reborn](https://github.com/liquidbounceplusreborn/LiquidbouncePlus-Reborn)
### [wdxbie](https://github.com/wxdbie) 
- Creating [LiquidBounce+ Reborn](https://github.com/liquidbounceplusreborn/LiquidbouncePlus-Reborn)
### [PlusPlusMC](https://github.com/PlusPlusMC) 
- Creating [LiquidBounce++](https://github.com/PlusPlusMC/LiquidbouncePlusPlus)
### [SkidderMC](https://github.com/SkidderMC) 
- Creating FDPClient
### [Coccocoa's Helper](https://github.com/gabrielvicenteYT) 
Created the "Original" FDPClient 2.0
Commiting in:
- LiquidBounce
- LiquidBounce+
- LiquidBounce++
- FDPClient
