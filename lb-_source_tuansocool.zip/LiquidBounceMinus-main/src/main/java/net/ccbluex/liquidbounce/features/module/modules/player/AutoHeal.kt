package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.InventoryUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
import net.minecraft.network.play.client.C09PacketHeldItemChange
import net.minecraft.potion.Potion
import net.minecraft.init.Items
import net.minecraft.item.ItemStack

@ModuleInfo(name = "AutoHeal", description = "Auto heal with gapple and potion.", category = ModuleCategory.PLAYER)
class AutoHeal: Module() {
    private val healthValue = FloatValue("Health", 15f, 0f, 20f)

    private val maxdelayValue: IntegerValue = object : IntegerValue("MaxDelay", 1000, 0, 5000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val i = mindelayValue.get()
            if (i > newValue) set(i)
        }
    }

    private val mindelayValue: IntegerValue = object : IntegerValue("MinDelay", 1000, 0, 5000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val i = maxdelayValue.get()
            if (i < newValue) set(i)
        }
    }
    private val debug = BoolValue("Debug", false)

    private val Delay = MSTimer()
    private var delay: Int = 0
    var doAutoHeal = true

    override fun onEnable() {
        delay = mindelayValue.get()
        doAutoHeal = false
        Delay.reset()
    }

    fun debug(message: String) {
        if (debug.get()) ClientUtils.displayChatMessage(message)
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (mc.thePlayer.health < healthValue.get()) doAutoHeal = true

        if (mc.thePlayer.absorptionAmount > 0f) {
            doAutoHeal = false
            mc.gameSettings.keyBindUseItem.pressed = false
        }

        if (doAutoHeal && Delay.hasTimePassed(delay.toLong())) {
            Delay.reset()
            delay = RandomUtils.nextInt(mindelayValue.get(), maxdelayValue.get())
            val gappleSlot = InventoryUtils.findItem(36, 44, Items.golden_apple)
            if (gappleSlot != -1) {
                mc.thePlayer.inventory.currentItem = gappleSlot - 36
                mc.playerController.updateController()
                mc.gameSettings.keyBindUseItem.pressed = true
            }
        }
    }
}