package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent

@ModuleInfo(name = "AutoJump", description = "Jumps automatically.", category = ModuleCategory.MOVEMENT)
class AutoJump: Module() {
	@EventTarget
	fun onUpdate(event: UpdateEvent) {
		if (mc.thePlayer.onGround) mc.thePlayer.jump()
		mc.gameSettings.keyBindJump.pressed = false
	}
}