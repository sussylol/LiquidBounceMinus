package net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.normal

import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.VelocityMode
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.play.server.S12PacketEntityVelocity
import net.minecraft.network.play.server.S32PacketConfirmTransaction

class Intave: VelocityMode("Intave") {
    private var counter = 0

    override fun onMotion(event: MotionEvent) {
        if (mc.thePlayer.hurtTime == 9 && mc.thePlayer.onGround && counter++ % 2 == 0) mc.thePlayer.movementInput.jump = true
    }
}