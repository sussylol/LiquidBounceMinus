package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.ncp

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.event.EventState
import net.minecraft.item.ItemFood
import net.minecraft.item.ItemBucketMilk
import net.minecraft.item.ItemPotion
import net.minecraft.network.play.server.S30PacketWindowItems
import net.minecraft.network.play.client.C09PacketHeldItemChange


class Watchdog: NoSlowMode("Watchdog") {
	private val testValue = BoolValue("SendPacket", false)
	private val debugValue = BoolValue("Debug", false)

	override fun onMotion(event: MotionEvent) {
		if (testValue.get() && (!killaura.state || !killaura.blockingStatus) && event.eventState == EventState.PRE && mc.thePlayer.itemInUse != null) {
			val item = mc.thePlayer.itemInUse.item ?: return
			if (mc.thePlayer.isUsingItem && (item is ItemFood || item is ItemBucketMilk || item is ItemPotion) && mc.thePlayer.getItemInUseCount() >= 1)
				PacketUtils.sendPacketNoEvent(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))
		}
	}
	override fun onPacket(event: PacketEvent) {
		val packet = event.packet
		if (packet is S30PacketWindowItems && (mc.thePlayer.isUsingItem || mc.thePlayer.isBlocking)) {
			event.cancelEvent()
			if (debugValue.get())
				ClientUtils.displayChatMessage("detected reset item packet")
		}
	}

}