package net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.aac

import net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.LongJumpMode
import net.ccbluex.liquidbounce.utils.MovementUtils
class AACv2: LongJumpMode("AACv2") {
	override fun onUpdate() {
		mc.thePlayer.jumpMovementFactor = 0.09F
        mc.thePlayer.motionY += 0.0132099999999999999999999999999
        mc.thePlayer.jumpMovementFactor = 0.08F
        MovementUtils.strafe()
	}
}
