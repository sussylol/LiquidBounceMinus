package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.other

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.minecraft.network.play.client.C09PacketHeldItemChange

class Matrix: NoSlowMode("Matrix") {

    private var nextTemp = false
    private val msTimer = MSTimer()
    private var lastBlockingStat = false
    override fun onMotion(event: MotionEvent) {
        if (!mc.thePlayer.isBlocking && !killaura.blockingStatus&& lastBlockingStat) return
        if(msTimer.hasTimePassed(230) && nextTemp) {
            nextTemp = false
    }
}