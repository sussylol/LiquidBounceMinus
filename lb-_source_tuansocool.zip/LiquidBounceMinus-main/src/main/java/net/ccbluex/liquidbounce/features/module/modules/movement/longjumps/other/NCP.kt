package net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.other

import net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.LongJumpMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.event.MoveEvent

class NCP: LongJumpMode("NCP") {
	private val ncpBoostValue = FloatValue("NCPBoost", 4.25F, 1F, 10F)
	private var canBoost = false

	override fun resetMotion() {
		mc.thePlayer.motionX = 0.0
        mc.thePlayer.motionZ = 0.0
	}

	override fun onUpdate() {
		val boost = if (canBoost) ncpBoostValue.get() else 1f
		MovementUtils.strafe(MovementUtils.getSpeed() * boost)
        canBoost = false
	}

	override fun onMove(event: MoveEvent) {
		if (!MovementUtils.isMoving() && longjump.jumped) {
            mc.thePlayer.motionX = 0.0
            mc.thePlayer.motionZ = 0.0
            event.zeroXZ()
        }
	}
}
