package net.ccbluex.liquidbounce.features.module.modules.movement.flys.normal

import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyType
import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyMode
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.minecraft.network.play.client.C00PacketKeepAlive

class KeepAlive: FlyMode("KeepAlive", FlyType.NORMAL) {
	private val vanillaSpeedValue = FloatValue("${prefix}Speed", 2f, 0f, 5f)

    override fun resetMotion() {}
    
    override fun onUpdate() {
        mc.netHandler.addToSendQueue(C00PacketKeepAlive())
        mc.thePlayer.capabilities.isFlying = false
        mc.thePlayer.motionY = 0.0
        mc.thePlayer.motionX = 0.0
        mc.thePlayer.motionZ = 0.0
        if(mc.gameSettings.keyBindJump.isKeyDown())
            mc.thePlayer.motionY += vanillaSpeedValue.get().toDouble()
        if(mc.gameSettings.keyBindSneak.isKeyDown())
            mc.thePlayer.motionY -= vanillaSpeedValue.get().toDouble()
        MovementUtils.strafe(vanillaSpeedValue.get())
    }
    override fun onRender3D() {}
}
