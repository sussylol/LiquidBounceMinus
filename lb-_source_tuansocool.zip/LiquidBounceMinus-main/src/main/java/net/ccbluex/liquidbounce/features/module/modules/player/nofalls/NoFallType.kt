package net.ccbluex.liquidbounce.features.module.modules.player.nofalls

enum class NoFallType(val typeName: String) {
    AAC("AAC"),
    NORMAL("Normal"),
    MATRIX("Matrix"),
    HYPIXEL("Hypixel"),
    OTHER("Other"),
}
