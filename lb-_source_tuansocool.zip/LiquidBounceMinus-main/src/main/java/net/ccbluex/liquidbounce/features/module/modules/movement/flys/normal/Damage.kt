package net.ccbluex.liquidbounce.features.module.modules.movement.flys.normal

import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyType
import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyMode

class Damage: FlyMode("Damage", FlyType.NORMAL) {
    override fun handleUpdate() {}
    
    override fun onUpdate() {
        mc.thePlayer.capabilities.isFlying = false
        if (mc.thePlayer.hurtTime <= 0) return
    }

    override fun onRender3D() {}
}