package net.ccbluex.liquidbounce.features.module.modules.movement.speeds

enum class SpeedType(val typeName: String) {
    AAC("AAC"),
    VULCAN("Vulcan"),
    NCP("NCP"),
    VERUS("Verus"),
    MATRIX("Matrix"),
    HYPIXEL("Hypixel"),
    OTHER("Other"),
}
