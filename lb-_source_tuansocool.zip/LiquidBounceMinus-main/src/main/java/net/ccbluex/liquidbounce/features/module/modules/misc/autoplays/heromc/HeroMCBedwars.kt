package net.ccbluex.liquidbounce.features.module.modules.misc.autoplays.heromc

import net.ccbluex.liquidbounce.features.module.modules.misc.autoplays.AutoPlayMode
import net.ccbluex.liquidbounce.event.PacketEvent


class HeroMCBedwars189: AutoPlayMode("HeroMC_Bedwars189") {
	override fun onEnable() {}
	override fun onUpdate() {}
	override fun onPacket(event: PacketEvent) {}
}