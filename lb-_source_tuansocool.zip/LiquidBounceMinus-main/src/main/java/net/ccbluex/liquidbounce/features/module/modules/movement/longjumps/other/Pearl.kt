package net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.other

import net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.LongJumpMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.PlayerUtils
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
import net.minecraft.network.play.client.C09PacketHeldItemChange
import net.minecraft.util.BlockPos

class Pearl: LongJumpMode("Pearl") {
	private val pearlBoostValue = FloatValue("${prefix}Boost", 4.25F, 0F, 10F)
    private val pearlHeightValue = FloatValue("${prefix}Height", 0.42F, 0F, 10F)
    private val pearlTimerValue = FloatValue("${prefix}Timer", 1F, 0.05F, 10F)

    private var pearlState: Int = 0
    private val dmgTimer = MSTimer()
    override fun onEnable() {
    	pearlState = 0
    }

	override fun onUpdateSpecial() {
		val enderPearlSlot = PlayerUtils.getPearlSlot()
        if (pearlState == 0) {
            if (enderPearlSlot == -1) {
                LiquidBounce.hud.addNotification(Notification("You don't have any ender pearl!", Notification.Type.ERROR))
                pearlState = -1
                longjump.state = false
                return                    
            }
            if (mc.thePlayer.inventory.currentItem != enderPearlSlot) {
                mc.thePlayer.sendQueue.addToSendQueue(C09PacketHeldItemChange(enderPearlSlot))
            }
            mc.thePlayer.sendQueue.addToSendQueue(C05PacketPlayerLook(mc.thePlayer.rotationYaw, 90f, mc.thePlayer.onGround))
            mc.thePlayer.sendQueue.addToSendQueue(C08PacketPlayerBlockPlacement(BlockPos(-1.0, -1.0, -1.0), 255, mc.thePlayer.inventoryContainer.getSlot(enderPearlSlot + 36).getStack(), 0f, 0f, 0f))
            if (enderPearlSlot != mc.thePlayer.inventory.currentItem) {
                mc.thePlayer.sendQueue.addToSendQueue(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))                    
            }
            pearlState = 1                    
        }

        if (pearlState == 1 && mc.thePlayer.hurtTime > 0) {
            pearlState = 2
            MovementUtils.strafe(pearlBoostValue.get())
            mc.thePlayer.motionY = pearlHeightValue.get().toDouble()
        }

        if (pearlState == 2) 
            mc.timer.timerSpeed = pearlTimerValue.get()
	}

	override fun onMove(event: MoveEvent) {
		if (pearlState != 2) event.cancelEvent()
	}
}
