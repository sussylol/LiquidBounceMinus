package net.ccbluex.liquidbounce.features.module.modules.movement.noslows

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.features.module.modules.movement.NoSlow
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.value.Value
import net.ccbluex.liquidbounce.utils.ClassUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.minecraft.network.play.client.C07PacketPlayerDigging
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
import net.minecraft.item.Item
import net.minecraft.item.ItemFood
import net.minecraft.item.ItemBucketMilk
import net.minecraft.item.ItemPotion
import net.minecraft.item.ItemSword
import net.minecraft.item.ItemBow
import net.minecraft.util.BlockPos
import net.minecraft.util.EnumFacing

abstract class NoSlowMode(val modeName: String): MinecraftInstance() {
    open val prefix = "${modeName}"

    protected val msTimer = MSTimer()
    protected val killaura: KillAura
        get() = LiquidBounce.moduleManager[KillAura::class.java]!!

    protected val noslow: NoSlow
        get() = LiquidBounce.moduleManager[NoSlow::class.java]!!

    open val values: List<Value<*>>
        get() = ClassUtils.getValues(this.javaClass, this)

    open fun onEnable() {
        msTimer.reset()
    }
    open fun onDisable() {}
    open fun onUpdate() {}
    open fun onPacket(event: PacketEvent) {}
    open fun onMotion(event: MotionEvent) {}
    open fun onSlowDown(event: SlowDownEvent) {
        val heldItem = mc.thePlayer.heldItem?.item
        event.forward = getMultiplier(heldItem, true)
        event.strafe = getMultiplier(heldItem, false)
    }

    open fun sendPacket(event: MotionEvent, sendC07: Boolean, sendC08: Boolean, delay: Boolean, delayValue: Long, onGround: Boolean, watchDog: Boolean = false) {
        val digging = C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos(-1,-1,-1), EnumFacing.DOWN)
        val blockPlace = C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem())
        val blockMent = C08PacketPlayerBlockPlacement(BlockPos(-1, -1, -1), 255, mc.thePlayer.inventory.getCurrentItem(), 0f, 0f, 0f)
        if(onGround && !mc.thePlayer.onGround) {
            return
        }
        if(sendC07 && event.eventState == EventState.PRE) {
            if(delay && msTimer.hasTimePassed(delayValue)) mc.netHandler.addToSendQueue(digging)
            else if(!delay) mc.netHandler.addToSendQueue(digging)
        }
        if(sendC08 && event.eventState == EventState.POST) {
            if(delay && msTimer.hasTimePassed(delayValue) && !watchDog) {
                mc.netHandler.addToSendQueue(blockPlace)
                msTimer.reset()
            } else if(!delay && !watchDog) mc.netHandler.addToSendQueue(blockPlace)
            else if(watchDog) mc.netHandler.addToSendQueue(blockMent)
        }
    }

    open fun getMultiplier(item: Item?, isForward: Boolean) = when (item) {
        is ItemFood, is ItemPotion, is ItemBucketMilk -> {
            if (isForward) noslow.consumeForwardMultiplier.get() else noslow.consumeStrafeMultiplier.get()
        }
        is ItemSword -> {
            if (isForward) noslow.blockForwardMultiplier.get() else noslow.blockStrafeMultiplier.get()
        }
        is ItemBow -> {
            if (isForward) noslow.bowForwardMultiplier.get() else noslow.bowStrafeMultiplier.get()
        }
        else -> 0.2F
    }
}