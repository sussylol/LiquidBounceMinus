package net.ccbluex.liquidbounce.features.module.modules.movement.flys

enum class FlyType(val typeName: String) {
    AAC("AAC"),
    HYPIXEL("Hypixel"),
    NCP("NCP"),
    NORMAL("Normal"),
    OTHER("Other"),
    SPARTAN("Spartan"),
    VERUS("Verus"),
    ZONECRAFT("Zonecraft"),
}
