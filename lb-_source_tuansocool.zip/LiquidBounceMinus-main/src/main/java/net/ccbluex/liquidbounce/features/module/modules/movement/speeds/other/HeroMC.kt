package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedType
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.event.MotionEvent
import net.minecraft.client.settings.GameSettings
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.module.modules.movement.InvMove
import net.minecraft.client.gui.GuiChat
import net.minecraft.client.gui.GuiIngameMenu
import net.minecraft.client.gui.inventory.GuiContainer
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.potion.Potion


class HeroMC: SpeedMode("HeroMC", SpeedType.OTHER) {

    private val cpuSPEED = BoolValue("HeroMC Timer Bypasses", true)
    override fun onUpdate() {
        if (cpuSPEED.get()) mc.timer.timerSpeed = 1.005f
        if (mc.thePlayer.isInWater) return
        if (MovementUtils.isMoving()) {
            if (mc.thePlayer.onGround) mc.thePlayer.jump()
        }
    }
}