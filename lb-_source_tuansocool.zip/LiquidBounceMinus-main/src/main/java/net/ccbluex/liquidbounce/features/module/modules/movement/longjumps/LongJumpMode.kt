package net.ccbluex.liquidbounce.features.module.modules.movement.longjumps

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.features.module.modules.movement.LongJump
import net.ccbluex.liquidbounce.value.Value
import net.ccbluex.liquidbounce.utils.ClassUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import java.awt.Color

abstract class LongJumpMode(val modeName: String): MinecraftInstance() {
	open val prefix = "${modeName}"

    protected var startY = 0.0

	protected val longjump: LongJump
		get() = LiquidBounce.moduleManager[LongJump::class.java]!!

	open val values: List<Value<*>>
		get() = ClassUtils.getValues(this.javaClass, this)

	// NCP
	open fun resetMotion() {}

	open fun onEnable() {}
	open fun onDisable() {}
    open fun onUpdate() {}
    open fun onUpdateSpecial() {}
    open fun onPacket(event: PacketEvent) {}
    open fun onMove(event: MoveEvent) {}
    open fun onJump(event: JumpEvent) {}
    open fun onStep(event: StepEvent) {}
}
