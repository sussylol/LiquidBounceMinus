package net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.mineplex

import net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.LongJumpMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.event.JumpEvent
class Mineplex: LongJumpMode("Mineplex") {
	override fun onUpdate() {
		mc.thePlayer.motionY += 0.0132099999999999999999999999999
        mc.thePlayer.jumpMovementFactor = 0.08F
        MovementUtils.strafe()
	}

	override fun onJump(event: JumpEvent) {
		if (longjump.state) event.motion = event.motion * 4.08f
	}
}
