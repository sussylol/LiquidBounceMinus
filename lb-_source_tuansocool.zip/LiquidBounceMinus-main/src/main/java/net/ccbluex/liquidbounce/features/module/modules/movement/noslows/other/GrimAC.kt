package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.other

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.play.client.C09PacketHeldItemChange

class GrimAC: NoSlowMode("GrimAC") {
    override fun onMotion(event: MotionEvent) {
        if (!mc.thePlayer.isBlocking && !killaura.blockingStatus) return
        PacketUtils.sendPacketNoEvent(C09PacketHeldItemChange((mc.thePlayer.inventory.currentItem + 1) % 9))
        PacketUtils.sendPacketNoEvent(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))
    }
}