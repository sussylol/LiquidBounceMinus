/*
 * LiquidBounce++ Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/PlusPlusMC/LiquidBouncePlusPlus/
 */
package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification
import net.minecraft.network.play.server.S02PacketChat
import net.minecraft.network.play.server.S45PacketTitle
import net.minecraft.network.Packet
import net.minecraft.network.play.client.C01PacketChatMessage
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.utils.misc.StringUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.TextValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "AutoHypixel", spacedName = "Auto Hypixel", description = "Auto Join Hypixel Skywar.", category = ModuleCategory.MISC)
class AutoHypixel : Module() {

    private val autoRejoin = BoolValue("Auto Rejoin", false)
    private val autoPlay = BoolValue("Auto Play", false)
    private val autoGG = BoolValue("Auto GG", false)
    private val sendDelay = FloatValue("Send Delay", 1000, 0, 10000, 100)
    private val winOnly = BoolValue("Win Only", false)
    private val playmodeValue = ListValue("Play Mode", arrayOf("Skywars, Bedwars"), "Skywars")
    private val skywarmodeValue = ListValue("Skywar Mode", arrayOf("Insane", "Solo"), "Insane")
    private val bedwarmodeValue = ListValue("Bedwar Mode", arrayOf("Solo", "Doubles", "Triples", "Quads"), "Solo")
    private val playDelay = FloatValue("Play Delay", 3000, 0, 10000, 100)



}