package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.normal

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.event.MotionEvent

class Custom: NoSlowMode("Custom") {
	private val customRelease = BoolValue("CustomReleasePacket", false)
	private val customPlace = BoolValue("CustomPlacePacket", false)
	private val customOnGround = BoolValue("CustomOnGround", false)
	private val customDelayValue = IntegerValue("CustomDelay", 60, 0, 1000, "ms")

	override fun onMotion(event: MotionEvent) {
		if (!mc.thePlayer.isBlocking && !killaura.blockingStatus) return
		sendPacket(event, customRelease.get(), customPlace.get(), customDelayValue.get() > 0, customDelayValue.get().toLong(), customOnGround.get())
	}
}