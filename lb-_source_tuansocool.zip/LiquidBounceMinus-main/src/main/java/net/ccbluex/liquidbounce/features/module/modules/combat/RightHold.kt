package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.player.AutoHeal
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.minecraft.item.ItemSword

@ModuleInfo(name = "RightHoldAB", description = "Autoblock right click", category = ModuleCategory.COMBAT)
class RightHold : Module() {

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val autoHeal = LiquidBounce.moduleManager[AutoHeal::class.java]!!
        val killAura = LiquidBounce.moduleManager[KillAura::class.java]!!
        if (mc.thePlayer == null || (autoHeal.state && autoHeal.doAutoHeal)) return
        mc.gameSettings.keyBindUseItem.pressed = mc.thePlayer.heldItem!!.item is ItemSword && killAura.target != null
    }

    override fun onDisable() {
        mc.gameSettings.keyBindUseItem.pressed = false
    }
}