package net.ccbluex.liquidbounce.features.module.modules.movement.flys.other

import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyType
import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyMode
import net.ccbluex.liquidbounce.utils.MovementUtils

class WatchCat: FlyMode("WatchCat", FlyType.OTHER) {
	override fun onUpdate() {
		MovementUtils.strafe(0.15f)
        mc.thePlayer.setSprinting(true)

        if(mc.thePlayer.posY < startY + 2) {
            mc.thePlayer.motionY = Math.random() * 0.5
            return
        }

        if(startY > mc.thePlayer.posY)
            MovementUtils.strafe(0f)
        return
	}
}