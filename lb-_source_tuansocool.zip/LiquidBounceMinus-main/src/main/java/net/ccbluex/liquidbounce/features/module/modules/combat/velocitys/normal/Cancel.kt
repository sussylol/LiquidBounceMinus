package net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.normal

import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.VelocityMode
import net.ccbluex.liquidbounce.event.PacketEvent
import net.minecraft.network.play.server.S12PacketEntityVelocity

class Cancel: VelocityMode("Cancel") {

    override fun onPacket(event: PacketEvent) {
        if (event.packet is S12PacketEntityVelocity) event.cancelEvent()
    }
}