package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.event.*
import net.minecraft.entity.player.EntityPlayer
import net.ccbluex.liquidbounce.value.TextValue
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "Killsults", description = "Insults people when you kill them.", category = ModuleCategory.MISC)
class KillSults: Module() {
	private val modeValue = ListValue("Mode", arrayOf("LB-", "HeroMC", "Redesky", "Lettuce", "Other", "Custom", "Watchdog", "Rise"), "HeroMC")
	private val customName = TextValue("CustomName", "khoi", {modeValue.get().equals("Rape") || modeValue.get().equals("NamKi")})

	private val heroMCInsults = arrayOf(
			"I'm not hacking it's just my Intel Core I9 13900k RTX 4090Ti and 64GB RAM!")
	private val lbminusInsults = arrayOf(
			"Download LiquidBounceMinus đi %name% ",
			"Giờ mà còn dùng FDP gì nữa %name%",
			"Delete FDP today! Try to install LiquidBounceMinus",
			"Why someone don't use LiquidBounceMinus?",
			"Chắc là không giòn đâu %name% ",
			"When people play with you, it's considered charity work",
			"I know you're rage quitting but with that trash client, you'd be having the skill issue",
			"I don't care about the fact that I'm hacking I just care about how you died by using FDP",
			"Update Your gaming chair pls %name%",
			"Your client sucks to be honest",
			"It's a bird! It's a plane! No it's is LiquidBounceMinus",
			"That client is so trash I think you should download LiquidBounceMinus",
	)

	private val watchdogInsults = arrayOf(
			"[STAFF] [WATCHDOG] % banned you %name%",
			"[STAFF] [WATCHDOG] % reeled you",
	)

	private val lettuceInsults = arrayOf(
			"%name% is an FDP client user",
			"Sorry %name%. I'm just testing Lettuce client",
			"Your mom is fat, your dad is g-a-y. %name%",
			"*knock *knock. Who's there? Your mom!",
			"Better luck next time %name%",
			"L %name%",
			"Lettuce client, made by Phu Pham, ruado, khoi, cart, HoangLong",
			"Lettuce client lets %name% know that skill is.",
	)

	private val riseInsults = arrayOf(
			"Wow! My combo is Rise'n!",
			"Why would someone as bad as you not use Rise 6.0?",
			"Here's your ticket to spectator from Rise 6.0!",
			"I see you're a pay to lose player, huh?",
			"Do you need some PvP advice? Well Rise 6.0 is all you need.",
			"Hey! Wise up, don't waste another day without Rise.",
			"You didn't even stand a chance against Rise.",
			"We regret to inform you that your free trial of life has unfortunately expired.",
			"RISE against other cheaters by getting Rise!",
			"You can pay for that loss by getting Rise.",
			"Remember to use hand sanitizer to get rid of bacteria like you!",
			"Hey, try not to drown in your own salt.",
			"Having problems with forgetting to left click? Rise 6.0 can fix it!",
			"Come on, is that all you have against Rise 6.0?",
			"Rise up today by getting Rise 6.0!",
			"Get Rise, you need it.",
	)

	private val redeskyInsults = arrayOf(
			"You're so bad that if I played with you, I'd be losing every single game",
			"There's not enough adjectives to describe how bad you are",
			"Here's your ticket to spectator mode",
			"You're that kind of non-recycable trash that no one knows what to do with",
			"Are your hands freezing? Because you missed every single hit",
			"I must be in a deranked game if I'm in the lobby with you, %name%",
			"I'm not hacking it's just my 871619-B21 HP Intel Xeon 8180 2.5GHz DL380 G10 processor",
			"When people play with you, it's considered charity work",
			"I know you're rage quitting but with that aim, you'd be having trouble clicking the disconnect button",
			"I don't care about the fact that I'm hacking I just care how you died in a block game",
			"Your gaming chair expired mid-fight so that's how you lost %name%",
			"You're so special that you can be the password requirement",
			"%name% is the type of person who climbs over a glass wall to see what's on the other side",
			"It's a bird! It's a plane! No it's your rank falling!",
			"*yawn* I get so bored playing against you. That's okay though",
			"Damn you have the awareness of a sloth",
			"That aim is so trash I think the safest place to stand is in front of you",
	)

	private var target: EntityPlayer? = null

	override fun onEnable() {
		target = null
	}

	@EventTarget
	fun onAttack(event: AttackEvent) {
		if (event.targetEntity is EntityPlayer) target = event.targetEntity // xem fdp thu
	}

	@EventTarget
	fun onUpdate(event: UpdateEvent) {
		if (target != null && target!!.isDead) {
			val message = when (modeValue.get()) {
				"LB-" -> {
					lbminusInsults[(Math.random() * lbminusInsults.size).toInt()].replace("%name%", target!!.getName())
				}
				"HeroMC" -> {
					heroMCInsults[(Math.random() * heroMCInsults.size).toInt()].replace("%name%", target!!.getName())
				}
				"Redesky" -> {
					redeskyInsults[(Math.random() * redeskyInsults.size).toInt()].replace("%name%", target!!.getName())
				}
				"Watchdog" -> {
					watchdogInsults[(Math.random() * watchdogInsults.size).toInt()].replace("%name%", target!!.getName())
				}
				"Lettuce" -> {
					lettuceInsults[(Math.random() * lettuceInsults.size).toInt()].replace("%name%", target!!.getName())
				}
				"Rise" -> {
					riseInsults[(Math.random() * riseInsults.size).toInt()].replace("%name%", target!!.getName())
				}
				else -> " "
			}
			mc.thePlayer.sendChatMessage(message)
		}
		target = null
	}
	override val tag: String?
		get() = modeValue.get()
}