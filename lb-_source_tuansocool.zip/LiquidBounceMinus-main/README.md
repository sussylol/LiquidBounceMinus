<img width="120" height="120" align="left" style="float: left; margin: 0 10px 0 0;" alt="lb++" src="src/main/resources/assets/minecraft/liquidbounce-/big.png">

# LiquidBounceMinus                                  
     
Client Dành Riêng Cho HeroMC

### Info
[Discord](https://discord.gg/tuansocool)

# Các bạn có thể help update client!!!!!

Liên hệ: toidicakhia#8729

dit me tlz va tuan so cu
