package net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.mineplex

import net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.LongJumpMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.event.MoveEvent
class Mineplex3LongJump: LongJumpMode("Mineplex3") {
	override fun onUpdate() {
		mc.thePlayer.jumpMovementFactor = 0.09f
        mc.thePlayer.motionY += 0.0132099999999999999999999999999
        mc.thePlayer.jumpMovementFactor = 0.08f
        MovementUtils.strafe()
	}

	override fun onMove(event: MoveEvent) {
		if(mc.thePlayer.fallDistance != 0f) mc.thePlayer.motionY += 0.037
	}
}
