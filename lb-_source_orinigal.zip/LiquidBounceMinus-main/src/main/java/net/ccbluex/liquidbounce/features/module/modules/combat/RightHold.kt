package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.minecraft.item.ItemSword

@ModuleInfo(name = "RightHoldAB", description = "Autoblock right click", category = ModuleCategory.COMBAT)
class RightHoldAB : Module() {

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val killAura = LiquidBounce.moduleManager[KillAura::class.java]!!
        if (mc.thePlayer == null) return
        mc.gameSettings.keyBindUseItem.pressed = mc.thePlayer.heldItem!!.item is ItemSword && killAura.currentTarget != null
    }

    override fun onDisable() {
        mc.gameSettings.keyBindUseItem.pressed = false
    }

}
