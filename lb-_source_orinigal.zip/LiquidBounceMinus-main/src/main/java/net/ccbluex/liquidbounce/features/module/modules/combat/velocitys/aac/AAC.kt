package net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.aac

import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.VelocityMode
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.network.play.server.S12PacketEntityVelocity
import net.ccbluex.liquidbounce.utils.MovementUtils

class AAC: VelocityMode("AAC") {
	private val aacStrafeValue = BoolValue("${prefix}StrafeValue", false)
	private var velocityInput = false
	private val velocityTimer = MSTimer()

	override fun onUpdate() {
		if (velocityInput && velocityTimer.hasTimePassed(50)) {
            mc.thePlayer.motionX *= velocity.horizontalValue.get()
            mc.thePlayer.motionZ *= velocity.horizontalValue.get()
            mc.thePlayer.motionY *= velocity.verticalValue.get()
            if(aacStrafeValue.get()) MovementUtils.strafe()
            velocityInput = false
        }
	}

	override fun onPacket(event: PacketEvent) {
		if (event.packet is S12PacketEntityVelocity) velocityInput = true
	}

}