package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.ncp

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.event.MotionEvent

class OldWatchdogNoSlow: NoSlowMode("OldWatchdog") {
	override fun onMotion(event: MotionEvent) {
		if (!mc.thePlayer.isBlocking && !killaura.blockingStatus) return
		if (mc.thePlayer.ticksExisted % 2 == 0)
            sendPacket(event, true, false, false, 50, true)
        else
            sendPacket(event, false, true, false, 0, true, true)
	}
}