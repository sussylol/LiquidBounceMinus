package net.ccbluex.liquidbounce.features.module.modules.movement.flys.normal

import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyType
import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition


class DerpFly: FlyMode("Derp", FlyType.NORMAL) {
	private val vanillaSpeedValue = FloatValue("${prefix}Speed", 2F, 0F, 5F)

	override fun onEnable() {}

	override fun onUpdate() {
        mc.thePlayer.capabilities.isFlying = false
        mc.thePlayer.motionY = 0.0
        mc.thePlayer.motionX = 0.0
        mc.thePlayer.motionZ = 0.0
        if (mc.gameSettings.keyBindJump.isKeyDown())
            mc.thePlayer.motionY += vanillaSpeedValue.get()
        if (mc.gameSettings.keyBindSneak.isKeyDown())
            mc.thePlayer.motionY -= vanillaSpeedValue.get()
        MovementUtils.strafe(vanillaSpeedValue.get())
	}

    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C03PacketPlayer) {
            packet.yaw = RandomUtils.nextFloat(0f, 360f)
            packet.pitch = RandomUtils.nextFloat(-90f, 90f)
        }
    }

    override fun onRender3D() {}
}

