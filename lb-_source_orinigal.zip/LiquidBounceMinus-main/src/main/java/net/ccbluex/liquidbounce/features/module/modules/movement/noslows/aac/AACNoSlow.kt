package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.aac

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.event.MotionEvent

class AACNoSlow: NoSlowMode("AAC") {
	override fun onMotion(event: MotionEvent) {
		if (!mc.thePlayer.isBlocking && !killaura.blockingStatus) return
		if (mc.thePlayer.ticksExisted % 3 == 0)
            sendPacket(event, true, false, false, 0, false)
        else
            sendPacket(event, false, true, false, 0, false)
	}
}