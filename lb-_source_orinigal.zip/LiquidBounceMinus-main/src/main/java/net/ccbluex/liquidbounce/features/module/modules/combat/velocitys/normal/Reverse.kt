package net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.normal

import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.VelocityMode
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.minecraft.network.play.server.S12PacketEntityVelocity
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.utils.timer.MSTimer

class Reverse: VelocityMode("Reverse") {
    private val reverseStrengthValue = FloatValue("${prefix}Strength", 1F, 0.1F, 1F, "x")
    private var velocityInput = false
    private val velocityTimer = MSTimer()
    
    override fun onUpdate() {
        if (!velocityInput)
            return
        if (!mc.thePlayer.onGround) {
            MovementUtils.strafe(MovementUtils.getSpeed() * reverseStrengthValue.get())
        } else if (velocityTimer.hasTimePassed(80L)) {
            velocityInput = false
            velocityTimer.reset()
        }
    }

    override fun onPacket(event: PacketEvent) {
        if (event.packet is S12PacketEntityVelocity) velocityInput = true
    }
}