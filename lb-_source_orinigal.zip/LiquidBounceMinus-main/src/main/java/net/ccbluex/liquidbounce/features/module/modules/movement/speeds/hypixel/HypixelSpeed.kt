package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.hypixel

import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedType
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.minecraft.potion.Potion

class HypixelSpeed: SpeedMode("Hypixel", SpeedType.HYPIXEL) {
    override fun onMotion(event: MotionEvent) {
        if (mc.thePlayer.onGround && MovementUtils.isMoving()) {
            mc.thePlayer.motionY = 0.41999998688698
            mc.thePlayer.jump()
            if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
                MovementUtils.strafe(0.485f)
            } else {
                MovementUtils.strafe(0.425f)
            }
        }
    }

    override fun onJump(event: JumpEvent) {
        if (mc.thePlayer != null && MovementUtils.isMoving())
            event.cancelEvent()
    }
}