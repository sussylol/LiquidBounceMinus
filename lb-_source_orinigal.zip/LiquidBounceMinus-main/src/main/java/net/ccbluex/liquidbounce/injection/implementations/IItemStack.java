/*
 * LiquidBounce-
 * https://github.com/MinusMC/LiquidBounceMinus/
 */
package net.ccbluex.liquidbounce.injection.implementations;

public interface IItemStack {
    long getItemDelay();
}
