package net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.normal

import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.VelocityMode
import net.ccbluex.liquidbounce.event.PacketEvent
import net.minecraft.network.play.server.S12PacketEntityVelocity

class Glitch: VelocityMode("Glitch") {
    private var velocityInput = false

    override fun onUpdate() {
        mc.thePlayer.noClip = velocityInput
        if (mc.thePlayer.hurtTime == 7)
            mc.thePlayer.motionY = 0.4

        velocityInput = false
    }

    override fun onPacket(event: PacketEvent) {
        if (event.packet is S12PacketEntityVelocity) {
            if (!mc.thePlayer.onGround) return
            velocityInput = true
            event.cancelEvent()
        }
    }
}