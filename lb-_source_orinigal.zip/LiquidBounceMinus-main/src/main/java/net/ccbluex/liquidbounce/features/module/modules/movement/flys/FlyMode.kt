package net.ccbluex.liquidbounce.features.module.modules.movement.flys

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.features.module.modules.movement.Fly
import net.ccbluex.liquidbounce.value.Value
import net.ccbluex.liquidbounce.utils.ClassUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyType
import java.awt.Color

abstract class FlyMode(val modeName: String, val typeName: FlyType): MinecraftInstance() {
	open val prefix = "${modeName}"

    protected var startY = 0.0

	protected val fly: Fly
		get() = LiquidBounce.moduleManager[Fly::class.java]!!

	open val values: List<Value<*>>
		get() = ClassUtils.getValues(this.javaClass, this)

    open fun initEnable() {
        startY = mc.thePlayer.posY
    }
    open fun resetMotion() {
        if (fly.resetMotionValue.get()) {
            mc.thePlayer.motionX = 0.0
            mc.thePlayer.motionY = 0.0
            mc.thePlayer.motionZ = 0.0
        }
    }

    open fun handleUpdate() {
        if (fly.fakeDmgValue.get()) mc.thePlayer.handleStatusUpdate(2.toByte())
    }

	open fun onEnable() {}
	open fun onDisable() {}
    open fun onUpdate() {}
    open fun onPacket(event: PacketEvent) {}
    open fun onMotion(event: MotionEvent) {}
    open fun onMove(event: MoveEvent) {}
    open fun onTick(event: TickEvent) {}
    open fun onRender2D() {}
    open fun onRender3D() {
        if (fly.markValue.get()) {
            val y = startY + 2
            val color = if (mc.thePlayer.entityBoundingBox!!.maxY < y) Color(0, 255, 0, 90) else Color(255, 0, 0, 90)
            RenderUtils.drawPlatform(y, color, 1.0)
        }
    }
    open fun onBlockBB(event: BlockBBEvent) {}
    open fun onJump(event: JumpEvent) {}
    open fun onStep(event: StepEvent) {}
}
