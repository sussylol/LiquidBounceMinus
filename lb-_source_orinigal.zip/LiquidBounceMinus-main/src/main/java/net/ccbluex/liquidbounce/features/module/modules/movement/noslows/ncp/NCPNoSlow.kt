package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.ncp

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.event.MotionEvent

class NCPNoSlow: NoSlowMode("NCP") {
	override fun onMotion(event: MotionEvent) {
		if (!mc.thePlayer.isBlocking && !killaura.blockingStatus) return
		sendPacket(event, true, true, false, 0, false)
	}
}