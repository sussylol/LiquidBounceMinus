package net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.other

import net.ccbluex.liquidbounce.features.module.modules.movement.longjumps.LongJumpMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.event.MoveEvent

class DamageLongJump: LongJumpMode("Damage") {
    private val damageBoostValue = FloatValue("${prefix}Boost", 4.25F, 0F, 10F)
    private val damageHeightValue = FloatValue("${prefix}Height", 0.42F, 0F, 10F)
    private val damageTimerValue = FloatValue("${prefix}Timer", 1F, 0.05F, 10F)
    private val damageNoMoveValue = BoolValue("${prefix}NoMove", false)
    private val damageARValue = BoolValue("${prefix}AutoReset", false)

    private var damaged = false

    override fun onEnable() {
    	damaged = false
    }

	override fun onUpdateSpecial() {
		if (mc.thePlayer.hurtTime > 0 && !damaged) {
            damaged = true
            MovementUtils.strafe(damageBoostValue.get())
            mc.thePlayer.motionY = damageHeightValue.get().toDouble()
        }
        if (damaged) {
            mc.timer.timerSpeed = damageTimerValue.get()
            if (damageARValue.get() && mc.thePlayer.hurtTime <= 0) damaged = false
        }

        return
	}

	override fun onMove(event: MoveEvent) {
		if (damageNoMoveValue.get() && !damaged) event.zeroXZ()
	}
}
