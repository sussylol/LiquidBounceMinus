package net.ccbluex.liquidbounce.features.module.modules.players.nofalls

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.features.module.modules.player.NoFall
import net.ccbluex.liquidbounce.value.Value
import net.ccbluex.liquidbounce.utils.ClassUtils
import net.ccbluex.liquidbounce.features.module.modules.player.nofalls.NoFallType


abstract class NoFallMode(val modeName: String, val typeName: NoFallType): MinecraftInstance() {
	open val prefix = "${modeName}"

	protected val nofall: NoFall
		get() = LiquidBounce.moduleManager[NoFall::class.java]!!

	open val values: List<Value<*>>
		get() = ClassUtils.getValues(this.javaClass, this)

	open fun onEnable() {}

	open fun onDisable() {}

    open fun onUpdate() {}
    open fun onPacket(event: PacketEvent) {}
    open fun onMotion(event: MotionEvent) {}
    open fun onMove(event: MoveEvent) {}
    open fun onWorld(event: WorldEvent) {}
    open fun onJump(event: JumpEvent) {}
}
