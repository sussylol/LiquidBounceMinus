package net.ccbluex.liquidbounce.features.module.modules.movement.flys.ncp

import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyType
import net.ccbluex.liquidbounce.features.module.modules.movement.flys.FlyMode
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.event.PacketEvent
import net.minecraft.network.play.client.C03PacketPlayer


class NCPFly: FlyMode("NCP", FlyType.NCP) {
    private val ncpMotionValue = FloatValue("${prefix}Motion", 0f, 0f, 1f)

	override fun onUpdate() {
        mc.thePlayer.motionY = -ncpMotionValue.get().toDouble()

        if(mc.gameSettings.keyBindSneak.isKeyDown)
            mc.thePlayer.motionY = -0.5
        MovementUtils.strafe()
	}

    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C03PacketPlayer) packet.onGround = true
    }
}