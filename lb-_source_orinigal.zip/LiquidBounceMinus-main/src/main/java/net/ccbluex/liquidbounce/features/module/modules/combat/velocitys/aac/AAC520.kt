package net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.aac

import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.VelocityMode
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import net.minecraft.network.play.server.S12PacketEntityVelocity
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura

class AAC520: VelocityMode("AAC520") {
	private val aac5KillAuraValue = BoolValue("${prefix}Attack-Only", true)

	override fun onPacket(event: PacketEvent) {
		if (event.packet is S12PacketEntityVelocity) {
			val killAura = LiquidBounce.moduleManager[KillAura::class.java]!!
			event.cancelEvent()
        	if (!mc.isIntegratedServerRunning() && (!aac5KillAuraValue.get() || killAura.currentTarget != null)) mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX,1.7976931348623157E+308,mc.thePlayer.posZ,true))
		}
	}
}