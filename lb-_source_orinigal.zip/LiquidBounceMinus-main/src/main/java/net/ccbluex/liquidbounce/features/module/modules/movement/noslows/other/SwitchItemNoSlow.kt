package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.other

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.play.client.C09PacketHeldItemChange

class SwitchItemNoSlow: NoSlowMode("SwitchItem") {
	override fun onMotion(event: MotionEvent) {
		if (!mc.thePlayer.isBlocking && !killaura.blockingStatus) return
		PacketUtils.sendPacketNoEvent(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem  % 8 + 1))
		PacketUtils.sendPacketNoEvent(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))
	}
}