/*
 * LiquidBounce-
 * https://github.com/MinusMC/LiquidBounceMinus/
 */
package net.ccbluex.liquidbounce.ui.client

class GuiBackground {

    companion object {
        var enabled = true
        var particles = false
    }

}
