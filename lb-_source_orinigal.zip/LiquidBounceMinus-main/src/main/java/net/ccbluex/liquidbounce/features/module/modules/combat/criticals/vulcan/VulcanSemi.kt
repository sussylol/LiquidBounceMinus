package net.ccbluex.liquidbounce.features.module.modules.combat.criticals.vulcan

import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.features.module.modules.combat.criticals.CriticalMode
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
class VulcanSemi : CriticalMode("VulcanSemi") {
    private var attacks = 0
    
    override fun onEnable() {
        attacks = 0
    }
    
    override fun onAttack(event: AttackEvent) {
        attacks++
        if (attacks > 6) {
            mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.2, mc.thePlayer.posZ, false))
            mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.1216, mc.thePlayer.posZ, false))
            attacks = 0
        }
    }
}