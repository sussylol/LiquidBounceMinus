package net.ccbluex.liquidbounce.features.module.modules.movement.noslows.normal

import net.ccbluex.liquidbounce.features.module.modules.movement.noslows.NoSlowMode
import net.ccbluex.liquidbounce.event.SlowDownEvent

class VanillaNoSlow: NoSlowMode("Vanilla") {
	override fun onSlowDown(event: SlowDownEvent) {
		event.cancelEvent()
	}
}